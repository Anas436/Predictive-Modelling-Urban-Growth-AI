# UrbanFragmentation
Dataset containing the urban metrics related to the fragmentation of African cities
